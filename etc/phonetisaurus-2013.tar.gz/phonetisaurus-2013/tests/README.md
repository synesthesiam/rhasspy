Various Evaluation Tools

Josef Robert Novak -- 2013-

NOTE: You must run `make' in the ../src directory before 
      running make here.  That's just the way it is.

perplexity evaluation program:
 phonetisaurus-perp

entry to FSM conversion utility
 phonetisaurus-e2f


